﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QGuiApplication>
#include <QScreen>
#include <QFile>
#include <QCoreApplication>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libswscale/swscale.h>
#include <libavutil/imgutils.h>
}

void initFFmpeg() {
     avformat_network_init();
}

// ????云??造甸
void cleanupFFmpeg() {
    avformat_network_deinit();
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    threadPool = new QThreadPool();
    threadPool->setMaxThreadCount(4); // ??崤?纲ⅶ???锖?х????
    // ?吖?铿FFmpeg
       initFFmpeg();

    layoutInit();

    v4l2DevInit();
    v4l2StreamOn();




}

MainWindow::~MainWindow()
{
    /* 避???嗉????铿*/
    int i;
    //?藐?????    timer->stop();
    if (v4l2_fd != -1) {
        for (i = 0; i < FRAMEBUFFER_COUNT; ++i) {
            if (buffer_infos[i].start) {
                munmap(buffer_infos[i].start, buffer_infos[i].length);
            }
        }

        // 崎揠?囡???        int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        ioctl(v4l2_fd, VIDIOC_STREAMOFF, &type);
        ::close(v4l2_fd);
        v4l2_fd = -1;
    }


    if (videoCapture.isOpened()) {
        videoCapture.release();  // 避??囡?????
    }

    if (videoUpdateTimer != nullptr) {
        videoUpdateTimer->stop();  // 崎揠?????        delete videoUpdateTimer;
        videoUpdateTimer = nullptr;
    }

    // 避窒崤?烀?
    if (videoSlider != nullptr) {
        videoSlider->setValue(0);
    }

    if (udpSocket) {
        udpSocket->close();  // ?藐?卟??呤        delete udpSocket;    // 避??帔??
        udpSocket = nullptr; // 镪旱?拿????橙
        qDebug() << "UDP socket disconnected.";
    }

     cleanupFFmpeg();

    delete ui;
}

/* ?哨??吖?铿*/
void MainWindow::layoutInit()
{
    QList <QScreen *> list_screen = QGuiApplication::screens();

     /* 迁???嵘RM?颜?????ヨ???ぇ????????ぇ?*/
    #if __arm__
     /* 避???у? */
    this->resize(list_screen.at(0)->geometry().width(),
                list_screen.at(0)->geometry().height());
    qDebug() << "width:" << list_screen.at(0)->geometry().width();
    qDebug() << "height:" << list_screen.at(0)->geometry().height();

    #else
    /* ????莩???少????у?薏00x480 */
       this->resize(800, 480);

    #endif

    // ??崤?烀?镎哨?

     ui->adjustFrame_horizontalSlider->setValue(g_fps);     // ??崤?烀????? g_fps
    ui->adjustFrame_horizontalSlider->setRange(30, 100);  // ??崤?烀?镎哨?



    ui->start_pushButton->setEnabled(true);
    ui->close_pushButton->setEnabled(false);

    /* 镆???恃衍 */
   ui->origal_label->setScaledContents(true);
   ui->gray_label->setScaledContents(true);
   ui->binar_label->setScaledContents(true);
   ui->edge_label->setScaledContents(true);
   ui->centralwidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);


}


int MainWindow::v4l2DevInit()
{
    // ????????
    v4l2_fd = ::open("/dev/video1", O_RDWR);
    if (v4l2_fd < 0) {
        qWarning("锓???????");
        return false;
    }

     // ?ヨ???殉?赂????淖??
    struct v4l2_capability cap;
    if(::ioctl(v4l2_fd, VIDIOC_QUERYCAP,&cap) < 0 || !(cap.capabilities & V4L2_CAP_VIDEO_CAPTURE))
    {
        qWarning("??薏??????里??);
        ::close(v4l2_fd);
        return -1;
    }

    // ?????殉?赂????耪???砾寺??????铷???    printf("Device Information:\n");
    printf("driver name: %s\ncard name: %s\n",cap.driver,cap.card);
    printf("------------------------------------\n");

    //?ヨ???殉?赂???真???锖躁殉???卫    struct v4l2_fmtdesc fmtdesc;
    fmtdesc.index = 0;
    fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    printf("Support Format:\n");
    /* ?云??时贪??? */
    memset(&cam_fmts,0,sizeof(cam_fmts));
    while(0 == ::ioctl(v4l2_fd, VIDIOC_ENUM_FMT, &fmtdesc))
    {
        cam_fmts[fmtdesc.index].pixelformat  = fmtdesc.pixelformat;
        memcpy(cam_fmts[fmtdesc.index].description, fmtdesc.description,sizeof(fmtdesc.description));
        fmtdesc.index++;
    }

    //?ヨ???殉?赂?????铀?????х??    struct v4l2_frmsizeenum frmsize;
    struct v4l2_frmivalenum frmival;
    int i;
    frmsize.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    frmival.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;

    for(i = 0; cam_fmts[i].pixelformat; i++)
    {
         printf("format<0x%x>, description<%s>\n", cam_fmts[i].pixelformat, cam_fmts[i].description);
         /* ?????剡耪?ご???真???锖???里??????? */
         frmsize.index = 0;
         frmsize.pixel_format = cam_fmts[i].pixelformat;
         frmival.pixel_format = cam_fmts[i].pixelformat;
         while (0 == ::ioctl(v4l2_fd, VIDIOC_ENUM_FRAMESIZES, &frmsize)) {

             printf("size<%d*%d> ",frmsize.discrete.width,frmsize.discrete.height);
             frmsize.index++;

             /* 镏述???殉?怿??里?????*/
             while (0 == ::ioctl(v4l2_fd, VIDIOC_ENUM_FRAMEINTERVALS, &frmival)) {

                 printf("<%dfps>", frmival.discrete.denominator / frmival.discrete.numerator);
                 frmival.index++;
             }
             printf("\n");

         }
          printf("\n");
    }
     printf("-------------------------------------\n");



     /* 帏蜒??畅??????剡耪?ご?砾寺 */
     if(v4l2SetFormat()<0){
         printf("set format failed\n");
         return -1;
     }

     return 0;


}

int MainWindow::v4l2SetFormat()
{
    // ??崤囡???砾寺?40x480??JPEG?砾寺???浔囡????????砾寺??崤???????????殉???卫    struct v4l2_format fmt;
    memset(&fmt, 0, sizeof(fmt));
    fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    fmt.fmt.pix.width = PIXWIDTH;
    fmt.fmt.pix.height = PIXHEIGHT;
    fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG; // ??崤薏?JPEG?砾寺
    if (::ioctl(v4l2_fd, VIDIOC_S_FMT, &fmt) < 0) {
        qWarning("锓????崤囡???砾寺");
        ::close(v4l2_fd);
        return -1;
    }

    qDebug() << "set formay success\r\n";

    /* ?ゆ????这?溟??崤薏????????MJPEG耪???砾寺,?????ず?ヨ??????真MJPEG耪???砾寺 */
    if (V4L2_PIX_FMT_MJPEG != fmt.fmt.pix.pixelformat) {
        printf("Error: the device does not support MJPEG format!\n");
        return -1;
    }

    /* 镏述??百?????拆嚆匐*/
        printf("???囡???уぇ?%d * %d>, ??蝉?箍?:%d\n", fmt.fmt.pix.width, fmt.fmt.pix.height,fmt.fmt.pix.colorspace);

    //镏述?囡????????
    struct v4l2_streamparm streamparm;
    streamparm.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (0 > ::ioctl(v4l2_fd, VIDIOC_G_PARM, &streamparm)) {
        printf("get parm failed\n");
        return -1;
    }

    /* ?ゆ??????真?х???崤 */
   if (V4L2_CAP_TIMEPERFRAME & streamparm.parm.capture.capability) {
       streamparm.parm.capture.timeperframe.numerator = 1;
       streamparm.parm.capture.timeperframe.denominator = 30;//30fps
       if (0 > ::ioctl(v4l2_fd, VIDIOC_S_PARM, &streamparm)) {
           printf("Error:device do not support set fps\n");
           return -1;
       }
   }


    return 0;
}

int MainWindow::v4l2_init_buffer()
{
    //???囡?????铿  ???薏薏????厨???铿嗤??ヤ垫??殉?唬?淖?????锉???时??殉?у??????????铿?绁
    struct v4l2_requestbuffers reqbuf;
    reqbuf.count = FRAMEBUFFER_COUNT;       //?х?????燃雀
    reqbuf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    reqbuf.memory = V4L2_MEMORY_MMAP;
    if (0 > ::ioctl(v4l2_fd, VIDIOC_REQBUFS, &reqbuf)) {
        printf("request buffer failed\n");
        return -1;
    }
     printf("request buffer success\n");

    printf("Driver supports up to %d buffers.\n", reqbuf.count);


     /* 砧弃?????嗉?  囡??锉??铷???????遛??绁????夔?薏????????锉?芳?ヨ邃薏???夔?*/
     struct v4l2_buffer buf;
     unsigned int n_buffers = 0;
     /* calloc?畅?薏?uffer_infos淖??????呤???录珩?吖?铿??0*/
     buffer_infos = (struct buffer_info*)calloc(FRAMEBUFFER_COUNT,sizeof(struct buffer_info));

     for (n_buffers = 0; n_buffers < FRAMEBUFFER_COUNT; n_buffers++) {
         memset(&buf,0,sizeof(buf));
         buf.index = n_buffers;
         buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
         buf.memory = V4L2_MEMORY_MMAP;
         if(0 > ::ioctl(v4l2_fd, VIDIOC_QUERYBUF, &buf)){
             printf("VIDIOC_QUERYBUF failed\n");
             return -1;
         }

         //?铀??????????铿?茚???????箍????呤践绁
         buffer_infos[n_buffers].start = mmap(NULL, buf.length,PROT_READ | PROT_WRITE, MAP_SHARED,v4l2_fd, buf.m.offset);
         buffer_infos[n_buffers].length = buf.length;

         if (MAP_FAILED == buffer_infos[n_buffers].start) {
             printf("mmap error\n");
             return -1;
         }

     };

     printf("memory map success\n");

     //???囡????????ラ????妹颤?
     for(buf.index = 0; buf.index < FRAMEBUFFER_COUNT; buf.index++)
     {
         if(::ioctl(v4l2_fd, VIDIOC_QBUF, &buf) < 0)
         {
             printf("?ラ???卡\n");
             return -1;
         }
     }

     return 0;

}

int MainWindow::v4l2StreamOn()
{
    /* 帏蜒??畅????吡胀?buffer */
    if(v4l2_init_buffer()<0){
        printf("------------------------------------\n");
        return -1;
    }

    // ???囡???    int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if (::ioctl(v4l2_fd, VIDIOC_STREAMON, &type) < 0) {
        qWarning("囡?????淖?け?);
        return -1;
    }

    printf("open stream success\n");


    return 0;
}

int MainWindow::v4l2GetOneFrame(FrameBuffer *framebuf){
    //?吖?铿?elect()?ヨ???/O????窒?
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(v4l2_fd,&fds);

    //??崤?躁?锓履?薏s
    struct timeval tv;
    tv.tv_sec = 2;
    tv.tv_usec = 0;
    select(v4l2_fd+1,&fds,NULL,NULL,&tv);

    //??????????燃??    struct v4l2_buffer one_buf;
    memset(&one_buf,0,sizeof(one_buf));
    one_buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    one_buf.memory = V4L2_MEMORY_MMAP;

    // ???????夔?????箍???绁???薏薏?宿??彗呤??薏?ц??佟?锉??囡?????铿    if(0 > ioctl(v4l2_fd,VIDIOC_DQBUF,&one_buf)){
        printf("VIDIOC_DQBUF failed!\n");
        return -1;
    }

    //??uffer_infos薏?宿薇纲???幔???copy??ramebuf薏    memcpy(framebuf->buf,(char *)buffer_infos[one_buf.index].start,one_buf.bytesused);//bytesused ??ずbuf薏?宿??????呤???    framebuf->length = one_buf.bytesused;

    if(ioctl(v4l2_fd,VIDIOC_QBUF,&one_buf)==-1){
        printf("VIDIOC_QBUF failed\n");
        return -1;
    }

    return 0;
}

void MainWindow::videoShow(){

    FrameBuffer frame;
    QPixmap pix;

    //镏述?薏?ф??    v4l2GetOneFrame(&frame);
    pix.loadFromData(frame.buf, frame.length);

    // 酃?? QPixmap 薏OpenCV Mat
       QImage img = pix.toImage();
       cv::Mat mat(img.height(), img.width(), CV_8UC4, (void*)img.bits(), img.bytesPerLine());
       cv::Mat matBgr;

       if (mat.channels() == 4) {
           cv::cvtColor(mat, matBgr, cv::COLOR_BGRA2BGR);  // 酃??薏BGR ?砾寺
       } else {
           matBgr = mat;  // 迁??这?溟?BGR????ヤ??       }


       // 镆???吖?????云?赏HSV 铷??锂????川匐?甸
       if (isAutoExposureEnabled) {
           cv::Mat hsv;
           cv::cvtColor(matBgr, hsv, cv::COLOR_BGR2HSV);

           std::vector<cv::Mat> hsvChannels;
           cv::split(hsv, hsvChannels);

           // ?○? V ???????囿?
           int histSize = 256;  // 赏?巢镎哨?
           float range[] = {0, 256};
           const float* histRange = {range};
           cv::Mat hist;

           cv::calcHist(&hsvChannels[2], 1, 0, cv::Mat(), hist, 1, &histSize, &histRange, true, false);

           // ??赏?巢?赂????薏?           int totalPixels = matBgr.rows * matBgr.cols;
           float midtotalPixels = totalPixels * 0.5;
           int sum = 0;
           static int medianValue = 0;
           static int frameCounter = 0;
           const int processInterval = 10;  // ?10 ?у?????


           if (frameCounter % processInterval == 0) {

               for (int i = 0; i < histSize; ++i) {
                   sum += hist.at<float>(i);
                   if (sum > midtotalPixels) {
                       medianValue = i;
                       break;
                   }
               }
           }
           frameCounter++;

           // 淖?????川匐???           double currentMean = cv::mean(hsvChannels[2])[0];
           int targetMean = 0;

           if (currentMean < 100) {  // ????研菅??谆?????川匐               targetMean = std::max(medianValue + 30, 180);
           } else if (currentMean > 200) {  // ?????川???薇????川匐               targetMean = std::min(medianValue - 30, 120);
           } else {  // ?ｅ摄???薏能???川匐??薏?               targetMean = medianValue;
           }

           // 淖????块川匐           double exposureScale = targetMean / std::max(currentMean, 1.0);  // ????ら?
           hsvChannels[2].convertTo(hsvChannels[2], -1, exposureScale, 0);  // 帏研?赏?巢

           // ?云珩 HSV ????缕?锉?? BGR
           cv::merge(hsvChannels, hsv);
           cv::cvtColor(hsv, matBgr, cv::COLOR_HSV2BGR);
       }



       // ?拆??☆????
       if (isGammaCorrectionEnabled) {
           // ?○??殉?????川匐           cv::Mat hsv;
           cv::cvtColor(matBgr, hsv, cv::COLOR_BGR2HSV);
           std::vector<cv::Mat> hsvChannels;
           cv::split(hsv, hsvChannels);
           double meanBrightness = cv::mean(hsvChannels[2])[0];  // V????????川匐
           // ????殉?????川匐???块衙芑?           double gamma = 1.2;  // 亢???拆??????高????百????帏研?
           if (meanBrightness < 100) {  // ?殉?研菅锓??????拆???????赏?巢
               gamma = 1.5;  // ?哨???衙芑????殉?践川
           } else if (meanBrightness > 200) {  // ?殉??川锓????ぇ?拆?????中?赏?巢
               gamma = 0.8;  // ?哨ぇ??衙芑????殉??菅
           }

           // ????ユ赞?           cv::Mat lookUpTable(1, 256, CV_8U);
           uchar* p = lookUpTable.ptr();

           // ????ユ赞?????衙芑???           for (int i = 0; i < 256; ++i) {
               p[i] = cv::saturate_cast<uchar>(pow(i / 255.0, gamma) * 255.0);
           }

           // 匐???ユ赞?           cv::Mat correctedMat;
           cv::LUT(matBgr, lookUpTable, correctedMat);
           matBgr = correctedMat;  // ?赂散 BGR ?殉
       }


       if (isRecording) {
           // 迁???ｅ???殉???????ф朔淖嗉? frames ?里雀
           frames.push_back(matBgr);
       }

       // 酃?? OpenCV Mat ?QPixmap
       cv::cvtColor(matBgr, matBgr, cv::COLOR_BGR2RGB);  // ?BGR 酃??薏RGB

       QImage processedImg(matBgr.data, matBgr.cols, matBgr.rows, matBgr.step, QImage::Format_RGB888);

       pix = QPixmap::fromImage(processedImg);

       // ??ず?殉?QLabel
       pix = pix.scaled(ui->origal_label->width(), ui->origal_label->height(), Qt::KeepAspectRatio);
       ui->origal_label->setPixmap(pix);

}



/* ?????骤??? */
void MainWindow::timerStart(float fps){
    // 1000/33???赏0,?????犰薏????0?    timer->start(fps);
}


/* ?噪?????藐????避??????颖?藐???? */
void MainWindow::on_start_pushButton_clicked()
{
    timer = new QTimer(this);
    this->timerStart(1000 / g_fps);
    ui->start_pushButton->setEnabled(false);
    ui->close_pushButton->setEnabled(true);
    //????尹?????赂?????    connect(timer, &QTimer::timeout, this, &MainWindow::videoShow);

}

void MainWindow::on_close_pushButton_clicked()
{
    /* 避???嗉????铿*/
    int i;
    //?藐?????    timer->stop();
    if (v4l2_fd != -1) {
        for (i = 0; i < FRAMEBUFFER_COUNT; ++i) {
            if (buffer_infos[i].start) {
                munmap(buffer_infos[i].start, buffer_infos[i].length);
            }
        }

        // 崎揠?囡???        int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        ioctl(v4l2_fd, VIDIOC_STREAMOFF, &type);
        ::close(v4l2_fd);
        v4l2_fd = -1;
    }

    this->close();
}

// ???锆??囡??????void MainWindow::resumeVideoStream(float fps)
{
    // ?х茶?origal_label 薏??????佟?
    this->timerStart(fps);  // 崎???0ms?赂散薏????烀?
}

void MainWindow::on_takePicture_pushButton_clicked()
{
    // 1. 镏述??????ず?origal_label 薏???殉
    const QPixmap* pixmap = ui->origal_label->pixmap();
    if (pixmap == nullptr) {
        qWarning("????☆???ず?殉");
        return;
    }

    if (pixmap->isNull()) {
        qWarning("????☆???ず?殉");
        return;
    }

    // ?宣?囡???       timer->stop();

    // ?QPixmap 酃??薏QImage
    QImage img = pixmap->toImage();

    // 3. ??ュ?耪??????    if (img.isNull()) {
        qWarning("?殉酃????卡");
        return;
    }

    // 4. ?QImage 酃??薏OpenCV Mat
    cv::Mat mat(img.height(), img.width(), CV_8UC4, (void*)img.bits(), img.bytesPerLine());
    cv::Mat matBgr;

    // 迁???殉?BGRA (QImage 亢???砾寺)???锉?? BGR
    if (mat.channels() == 4) {
        cv::cvtColor(mat, matBgr, cv::COLOR_BGRA2BGR);

    } else {
        matBgr = mat;
    }

    // 5. 镆??????????绘巾胀? picture_20231110_134500.jpg?    QString defaultFileName = QString("picture_%1.jpg").arg(QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss"));

    // 6. ??????蘅吖??怆????????哜??蘅吖???逅铷?????
    QString fileName = QFileDialog::getSaveFileName(this, tr("蘅吖????"),
                                                     defaultFileName,  // 亢??????                                                     tr("JPEG Files (*.jpg);;PNG Files (*.png)"));
    if (fileName.isEmpty()) {
        return; // ??????赏????彗呤    }

    // 7. 蘅吖??殉
    std::string stdFileName = fileName.toStdString();
    if (!cv::imwrite(stdFileName, matBgr)) {
        qWarning("蘅吖??????卡");
    } else {
        qDebug() << "???这?彗呤??:" << fileName;
    }

    resumeVideoStream(1000/g_fps);
}



void MainWindow::on_playPicture_pushButton_clicked()
{
    // ?宣?囡???       timer->stop();

    // 1. ???????怆????????哜?????
    QString fileName = QFileDialog::getOpenFileName(this, tr("??????"), "", tr("JPEG Files (*.jpg);;PNG Files (*.png);;All Files (*)"));
    if (fileName.isEmpty()) {
        return; // ?????????
    }

    // 2. 薇纲? OpenCV 淖???殉
    cv::Mat img = cv::imread(fileName.toStdString()); // 薇纲? OpenCV 淖???殉
    if (img.empty()) {
        qWarning("淖???????卡");
        return;
    }

    // 3. ?OpenCV Mat 酃??薏QImage
    // 迁???BGR ?砾寺????缕?锉?? RGB ?砾寺
    cv::Mat imgRgb;
    if (img.channels() == 3) {
        cv::cvtColor(img, imgRgb, cv::COLOR_BGR2RGB); // BGR 酃RGB
    } else {
        imgRgb = img; // 迁?????匐??????ヤ??    }

    // ?OpenCV Mat 酃??薏QImage
    QImage qImg((const uchar*)imgRgb.data, imgRgb.cols, imgRgb.rows, imgRgb.step, QImage::Format_RGB888);

    // 4. ??ず?殉?QLabel
    if (qImg.isNull()) {
        qWarning("?殉酃????卡");
        return;
    }

    // ???耪????? QLabel
    ui->origal_label->setPixmap(QPixmap::fromImage(qImg));
}


void MainWindow::on_closePic_pushButton_clicked()
{
    resumeVideoStream(1000/g_fps);
}

void MainWindow::on_videoRecord_pushButton_clicked()
{
    if (isRecording) {
           // ????○????崎揠???殉
           isRecording = false;

           // 崎揠???殉??彗呤???           QString defaultFileName = QString("video_%1.mp4").arg(QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss"));

           // 卫囿?蘅吖?????怆??铀???????蘅吖???逅
           QString fileName = QFileDialog::getSaveFileName(this, tr("蘅吖?囡??"), defaultFileName, tr("MP4 Files (*.mp4);;AVI Files (*.avi)"));
           if (fileName.isEmpty()) {
               return; // ??????蘅吖?
           }

           // ??? VideoWriter ?怆泅????????彗呤??疹           videoWriter.open(fileName.toStdString(), cv::VideoWriter::fourcc('H', '2', '6', '4'), 1000/g_fps, frames[0].size()); // 30 FPS, H.264 ?坩?

           if (!videoWriter.isOpened()) {
               qWarning("囡???????卡?);
               return;
           }

           // ??????囡??
           for (const auto& frame : frames) {
               videoWriter.write(frame);  // ???囡???           }

           videoWriter.release();  // 避?? VideoWriter
           qDebug() << "囡??这?彗呤??:" << fileName;

           // ???这夔?????           frames.clear();

       } else {
           // ????○????卫吡胀?耪           isRecording = true;

           // ????胀???????
           frames.clear();

           // ??????锯律           qDebug() << "卫吡胀?耪..";
       }
}

// ???囡???噪?锪囿屿
void MainWindow::on_playVideo_pushButton_clicked()
{
    // 崎揠????囡??????    stopVideoStream();

    // ???????怆??铀???????囡?????
    QString fileName = QFileDialog::getOpenFileName(this, tr("???囡??"), "", tr("MP4 Files (*.mp4);;AVI Files (*.avi);;All Files (*)"));
    if (fileName.isEmpty()) {
        return; // ????????????
    }

    // ???囡?????
    videoCapture.open(fileName.toStdString());
    if (!videoCapture.isOpened()) {
        qWarning("锓?????囡??????);
        return;
    }

    // 镏述?囡??????饶??х?
    int frameCount = static_cast<int>(videoCapture.get(cv::CAP_PROP_FRAME_COUNT));
    double fps = videoCapture.get(cv::CAP_PROP_FPS);

    // ????律?????    videoSlider = new QSlider(Qt::Horizontal, this);
    videoSlider->setRange(0, frameCount);  // ??崤?烀?镎哨?
    videoSlider->setValue(0);  // ?吖????0
    ui->video_verticalLayout->addWidget(videoSlider);  // ?????朔淖嗉??哨?薏
    // ????烀???接?述?乍榇??        connect(videoSlider, &QSlider::valueChanged, this, &MainWindow::on_sliderValueChanged);



    // ????律????匐?擤
    videoProgressBar = new QProgressBar(this);
    videoProgressBar->setRange(0, frameCount);  // ??崤??巢????    videoProgressBar->setValue(0);  // ?吖????0
    ui->video_verticalLayout->addWidget(videoProgressBar);  // ?铀?匐?擤????饶??薏
    // ??ず囡?????薏?у? origal_label
    updateVideoFrame();

    // ?????????????赂散??巢?№?囡???    videoUpdateTimer = new QTimer(this);
    connect(videoUpdateTimer, &QTimer::timeout, this, &MainWindow::updateVideoProgress);
    videoUpdateTimer->start(1000 / fps);  // ????х???崤??????锓履??唬?
}

// ?赂散囡????巢?№???ず囡???void MainWindow::updateVideoProgress()
{
    if (videoCapture.isOpened()) {
        // 镏述???????????烀?????        int currentFrameIndex = static_cast<int>(videoCapture.get(cv::CAP_PROP_POS_FRAMES));


        // ?赂散?烀?铷??匐?擤??        videoSlider->setValue(currentFrameIndex);
        videoProgressBar->setValue(currentFrameIndex);

        // ???????у珩??ず?origal_label 薏        updateVideoFrame();
    }
}


// ?赂散??ず???????烀?
void MainWindow::updateVideoFrame()
{
    if (!videoCapture.isOpened()) {
        return;
    }



    // 镏述?????х????
      int currentFrameIndex = static_cast<int>(videoCapture.get(cv::CAP_PROP_POS_FRAMES));
      int totalFrames = static_cast<int>(videoCapture.get(cv::CAP_PROP_FRAME_COUNT));

      // 迁??????ф?这勉??惹??绎遛锂???????ず锖????      if (currentFrameIndex >= totalFrames) {
          videoCapture.set(cv::CAP_PROP_POS_FRAMES, totalFrames - 1);  // 卫尹???崤?惹?????          videoCapture >> currentFrame;  // ???锖????      } else {
          // 镏述?囡??????у?耪          videoCapture >> currentFrame;
      }

      if (currentFrame.empty()) {
              qWarning("囡???????卡????????");
              return;
          }

    // ?OpenCV Mat 酃??薏QImage???????尹? origal_label
    QImage img = QImage(currentFrame.data, currentFrame.cols, currentFrame.rows, currentFrame.step, QImage::Format_RGB888);
    ui->origal_label->setPixmap(QPixmap::fromImage(img));  // ??ず囡???}



// ?烀????锓律??俾????匐void MainWindow::on_sliderValueChanged(int value)
{
    if (videoCapture.isOpened()) {
        // ?铀??佟??剁?????录??烀?薇窒崤?囿????
        videoCapture.set(cv::CAP_PROP_POS_FRAMES, value);
        updateVideoFrame();  // ?赂散囡???ф??    }
}





void MainWindow::on_closeVideo_pushButton_clicked()
{
    // 崎揠?囡??????律簿????佟?
        stopVideoPlayback();

        // 避???烀?
        if (videoSlider != nullptr) {
            ui->video_verticalLayout->removeWidget(videoSlider);  // ????薏?Щ?ゆ??            delete videoSlider;  // ????烀?
            videoSlider = nullptr;  // ?????橙
        }


        resumeVideoStream(1000/g_fps);  // 锆????殉?怿??佟????????????ず
}

// 崎揠?囡?????
void MainWindow::stopVideoPlayback()
{
    if (videoCapture.isOpened()) {
        videoCapture.release();  // 避??囡?????
    }

    if (videoUpdateTimer != nullptr) {
        videoUpdateTimer->stop();  // 崎揠?????        delete videoUpdateTimer;
        videoUpdateTimer = nullptr;
    }

    // 避窒崤?烀?
    if (videoSlider != nullptr) {
        videoSlider->setValue(0);
    }

    // 避????巢?    if (videoProgressBar != nullptr) {
        ui->video_verticalLayout->removeWidget(videoProgressBar);  // ????薏?Щ?よ?匐?擤
        delete videoProgressBar;  // ?????巢?        videoProgressBar = nullptr;  // ?????橙
    }
}



// 崎揠?囡????珩锆???????ず????void MainWindow::stopVideoStream()
{
    timer->stop();
    qDebug() << "?宣????囡??????;
}


// ?噪?锪囿屿乍榇???嘿?????????匐??
void MainWindow::on_playGray_pushButton_clicked() {
    if (isGrayProcessing) {
        // 崎揠??饶巢铿        videoGrayTimer->stop();
        delete videoGrayTimer;
        videoGrayTimer = nullptr;
        isGrayProcessing = false;
        ui->gray_label->clear();  // ????殉铷??锖        ui->gray_label->setText("?饶巢?);  // ??崤?时????

        ui->playGray_pushButton->setText("卫吡能?匐??");


    } else {
        // ????????珩????饶巢铿???        videoGrayTimer = new QTimer(this);
        connect(videoGrayTimer, &QTimer::timeout, this, &MainWindow::startGrayProcessing);
        videoGrayTimer->start(1000 / g_fps);  // ?ч???嘿1000 ms / ?х?
        isGrayProcessing = true;
        ui->playGray_pushButton->setText("崎揠??饶巢铿);
    }
}

// ?????Е???乍榇???嘿????饶巢铿??淖void MainWindow::startGrayProcessing() {
    if (!isGrayProcessing) {
            // ??彗??????锂??薏?颖?х茶???
            return;
        }

    // ?QLabel 镏述?????殉
    const QPixmap* gray_origPixmap = ui->origal_label->pixmap();
    if (!gray_origPixmap || gray_origPixmap->isNull()) {
        QMessageBox::warning(this, "??ず", "????殉薏弃????詹?????");
        return;
    }

    // 酃?? QPixmap 薏QImage
    QImage inputImage = gray_origPixmap->toImage();

    // ????饶巢铿??淖    GrayTask* task = new GrayTask(inputImage);
    connect(task, &GrayTask::grayImageReady, this, &MainWindow::processGrayImage);

    // ???????时????
    QThreadPool::globalInstance()->start(task);
}

// ????饶巢铿??耪?嘿?ユ????????律??饶? QLabel
void MainWindow::processGrayImage(const QImage& grayImage) {
    if (!ui->gray_label) return;

    static  QSize labelGraySize;
    // 迁?????薏?э??赂???ず
    static bool isFirstFrame = true;
    if (isFirstFrame) {
        QPixmap pixmap = QPixmap::fromImage(grayImage);
        ui->gray_label->setPixmap(pixmap);
        ui->gray_label->adjustSize();  // 卫尹?帏研? QLabel ?尹?薏尹?耪?ぇ?        labelGraySize = ui->gray_label->size();
        isFirstFrame = false;

    } else {
        labelGraySize  = ui->gray_label->size();;
        // ?ɡ??殉?ラ宣? QLabel ??ぇ?        QPixmap scaledGrayPixmap = QPixmap::fromImage(grayImage).scaled(labelGraySize, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        ui->gray_label->setPixmap(scaledGrayPixmap);
    }
}


// ??????????砾????
void MainWindow::on_playBinary_pushButton_clicked() {
    if (isBinaryProcessing) {
        // 崎揠?赏?砾?
        binaryTimer->stop();
        delete binaryTimer;
        binaryTimer = nullptr;
        isBinaryProcessing = false;

        // ??? binar_label 薏????ず
        ui->binar_label->clear();
        ui->binar_label->setText("赏?砾??);

        ui->playBinary_pushButton->setText("卫吡???砾?");
    } else {
        // ????????珩???
        binaryTimer = new QTimer(this);
        connect(binaryTimer, &QTimer::timeout, this, &MainWindow::startBinaryProcessing);

        // ??崤????????绘????х???崤?唬?锓履??        binaryTimer->start(1000 / g_fps);
        isBinaryProcessing = true;
        ui->playBinary_pushButton->setText("崎揠?赏?砾?");
    }
}

// ?????Е???乍榇???嘿???赏?砾????
void MainWindow::startBinaryProcessing() {
    // ?origal_label 镏述?????殉
    const QPixmap* binary_origPixmap = ui->origal_label->pixmap();
    if (!binary_origPixmap || binary_origPixmap->isNull()) {
        QMessageBox::warning(this, "??ず", "????殉薏弃????詹?????");
        return;
    }
    // 酃?? QPixmap 薏QImager
    QImage inputImage = binary_origPixmap->toImage();

    // ??? BinaryTask ???
    BinaryTask* task = new BinaryTask(inputImage);

    // ?????????蘅№资?惹Ы?畅?
    connect(task, &BinaryTask::binaryImageReady, this, &MainWindow::processBinaryImage);

    // ???????时????
    QThreadPool::globalInstance()->start(task);
}

// ?ユ?赏?砾?????????珩?赂散 binar_label
void MainWindow::processBinaryImage(const QImage& binaryImage) {
    if (!ui->binar_label)
    {
        qDebug() << "?☆?镏述?赏?砾????";
        return;
    }
    static  QSize labelBinarySize;       // ???呤瞅?赏?砾? QLabel ??狗?    static bool isFirstBinay = true;

    if(isFirstBinay)
    {
        QPixmap binaryPixmap = QPixmap::fromImage(binaryImage);
        ui->binar_label->setPixmap(binaryPixmap);
        ui->binar_label->adjustSize();  // 卫尹?帏研? QLabel ?尹?薏尹?耪?ぇ?        labelBinarySize = ui->gray_label->size();
        isFirstBinay = false;
    }
    else{
        // 镏述? QLabel ?????ぇ????ɡ??殉
        QSize labelBinarySize = ui->binar_label->size();
        QPixmap scaledBinaryPixmap = QPixmap::fromImage(binaryImage).scaled(labelBinarySize, Qt::KeepAspectRatio, Qt::SmoothTransformation);

        // ?赂散 QLabel ??ず
        ui->binar_label->setPixmap(scaledBinaryPixmap);
    }


}

void MainWindow::on_playEdge_pushButton_clicked()
{
    if (isEdgeProcessing) {
          // 崎揠??方???          edgeTimer->stop();
          delete edgeTimer;
          edgeTimer = nullptr;
          isEdgeProcessing = false;

          // ??? edge_label 薏????ず
          ui->edge_label->clear();
          ui->edge_label->setText("?方??);

          ui->playEdge_pushButton->setText("卫吡?痫????);
      } else {
          // ????????珩???
          edgeTimer = new QTimer(this);
          connect(edgeTimer, &QTimer::timeout, this, &MainWindow::startEdgeProcessing);
          edgeTimer->start(1000 / g_fps);
          isEdgeProcessing = true;

          ui->playEdge_pushButton->setText("崎揠??方???);
      }
}

void MainWindow::startEdgeProcessing() {
    // 镏述?????殉
    const QPixmap* origEdgePixmap = ui->origal_label->pixmap();
    if (!origEdgePixmap || origEdgePixmap->isNull()) {
        qWarning() << "No image found in origal_label!";
        return;
    }

    // 酃?? QPixmap 薏QImage
    QImage inputEdgeImage = origEdgePixmap->toImage();

    // ????方?????淖    EdgeDetection* task = new EdgeDetection(inputEdgeImage);
    connect(task, &EdgeDetection::edgeImageReady, this, &MainWindow::processEdgeImage);

    // ???????时????
    QThreadPool::globalInstance()->start(task);
}

void MainWindow::processEdgeImage(const QImage& edgeImage) {
    if (!ui->edge_label) return;

    static QSize labelEdgeSize;
    static bool isFirstEdge = true;

    if(isFirstEdge)
    {
        QPixmap edgePixmap = QPixmap::fromImage(edgeImage);
        ui->edge_label->setPixmap(edgePixmap);
        ui->edge_label->adjustSize();
        labelEdgeSize = ui->edge_label->size();
        isFirstEdge = false;
    }
    else
    {
        QPixmap scaleEdgePixmap = QPixmap::fromImage(edgeImage).scaled(labelEdgeSize, Qt::KeepAspectRatio, Qt::SmoothTransformation);
        ui->edge_label->setPixmap(scaleEdgePixmap);
    }

}

void MainWindow::on_adjustFrame_horizontalSlider_valueChanged(int value)
{


    g_fps = value; // ?赂散?????雀?х?
     ui->frame_lineEdit->setText(QString::number(g_fps, 'f', 2)); // 蘅??薏や??????ず

    qDebug() << "Frame rate adjusted to:" << g_fps;
}




void MainWindow::on_autoExp_pushButton_clicked()
{
    isAutoExposureEnabled = !isAutoExposureEnabled;

       if (isAutoExposureEnabled) {
           ui->autoExp_pushButton->setText("?藐?");
       } else {
           ui->autoExp_pushButton->setText("卫?);
       }
}

void MainWindow::on_autoGain_pushButton_clicked()
{
    isAutoGainEnabled = !isAutoGainEnabled;  // ?????????锯律
        // ?噪???????
        if (isAutoGainEnabled) {
            ui->autoGain_pushButton->setText("崎揠?");
        } else {
            ui->autoGain_pushButton->setText("卫?);
        }

}

void MainWindow::on_gammaCor_pushButton_clicked()
{
    isGammaCorrectionEnabled = !isGammaCorrectionEnabled;  // ????拆??☆????锯律
        // ?噪???????
        if (isGammaCorrectionEnabled) {
            ui->gammaCor_pushButton->setText("崎揠??拆??☆?");
        } else {
            ui->gammaCor_pushButton->setText("卫??衙芑???);
        }
}

void MainWindow::on_uploadServer_pushButton_clicked() {
    if (!isConnectServer) {
        // ?吖?铿???ワ???? QUdpSocket ?怆泅
        udpSocket = new QUdpSocket();
        isConnectServer = true;
        ui->uploadServer_pushButton->setText("??????");
        qDebug() << "????里??锉??锖???;

        // ????时???????????惹??????????帙        if (!ProcessImageTimer) {  // ??彗???砧???№?锓??
            ProcessImageTimer = new QTimer();
            connect(ProcessImageTimer, &QTimer::timeout, this, &MainWindow::startProcessImage);
            ProcessImageTimer->start(g_fps*10);
        }
    } else {
        // ??????
        isConnectServer = false;
        ui->uploadServer_pushButton->setText("???锖???);
        qDebug() << "崎揠??里??锉;


    }
}

void MainWindow::startProcessImage() {

    if (isConnectServer) {
        // ?`origal_label` 镏述??殉
        QLabel *origalLabel = ui->origal_label;
        QImage image = origalLabel->pixmap()->toImage();
        // 帏研??殉?у?薏640x480
        resizedImageProcessImage = image.scaled(640, 480, Qt::KeepAspectRatio, Qt::SmoothTransformation);

        // ????殉?缕?????坩?????惹?
        ProcessImage *ProcessImageTask = new ProcessImage(resizedImageProcessImage, g_fps);
        connect(ProcessImageTask, &ProcessImage::dataReadyToUpload, this, &MainWindow::uploadDataToServer);

        threadPool->start(ProcessImageTask);
    } else {
        // 崎揠?????        if (ProcessImageTimer) {
            ProcessImageTimer->stop();
            delete ProcessImageTimer;
            ProcessImageTimer = nullptr;
        }

    }
}

// ?里RTP ?惹?
void MainWindow::uploadDataToServer(const QByteArray &data) {
    qDebug() << "Uploading data to server, size:" << data.size();

    // ??遛 UDP ?里RTP 铿
    if (udpSocket->writeDatagram(data, QHostAddress("192.168.5.11"), 20000) == -1) {
        qDebug() << "Error sending RTP packet:" << udpSocket->errorString();
    } else {
        qDebug() << "RTP packet sent successfully!";
    }
}


void MainWindow::on_uploadServer_pushButton_clicked()
{

}

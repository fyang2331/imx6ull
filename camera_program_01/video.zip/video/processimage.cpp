﻿#include "processimage.h"
#include <QDebug>

ProcessImage::ProcessImage(const QImage &image, int fps)
    : image(image), fps(fps) {}

ProcessImage::~ProcessImage() {
    avcodec_free_context(&codecContext);
    av_packet_free(&pkt);
    av_frame_free(&avFrame);
}

void ProcessImage::run() {

     if(initializeEncoder()!=true)
     {
         qDebug() << "初始化编码器失败";
         return;
     }

    sendFrame(image);
}


bool ProcessImage::initializeEncoder() {
    codec = avcodec_find_encoder(AV_CODEC_ID_H264);
    if (!codec) {
        qDebug() << "无法找到 H.264 编码器";
        return false;
    }

    codecContext = avcodec_alloc_context3(codec);
    codecContext->bit_rate = 500000; // 500kbps 码率
    codecContext->width = 640;
    codecContext->height = 480;
    codecContext->time_base = {1, 33};
    codecContext->framerate = {33, 1};
    codecContext->pix_fmt = AV_PIX_FMT_YUV420P;

    // 在打开编码器之前设置 "zerolatency" 模式
      if (av_opt_set(codecContext->priv_data, "tune", "zerolatency", 0) < 0) {
          qDebug() << "无法设置零延迟模式";
          return false;
      }

    if (avcodec_open2(codecContext, codec, nullptr) < 0) {
        qDebug() << "无法打开 H.264 编码器";
        return false;
    }

    pkt = av_packet_alloc();
    avFrame = av_frame_alloc();
    avFrame->format = codecContext->pix_fmt;
    avFrame->width = codecContext->width;
    avFrame->height = codecContext->height;
    av_frame_get_buffer(avFrame, 32);
    qDebug() << "initializeEncoder is ok";
    return true;
}

void ProcessImage::sendFrame(const QImage &image) {
    qDebug() << "sendFrame is start";
    Mat frame = Mat(image.height(), image.width(), CV_8UC3, (void *)image.bits(), image.bytesPerLine()).clone();
    cv::resize(frame, frame, Size(640, 480));
    if (frame.empty()) {
        qDebug() << "frame is empty!";
        return;
    } else {
        qDebug() << "frame is not empty, size:" << frame.cols << "x" << frame.rows;
    }

    QVector<uchar> encodedData;

    if (!encodeFrameH264(frame, encodedData)) {
        qDebug() << "H.264 编码失败！";
        return;
    }

    sendUdpPackets(encodedData);
}

bool ProcessImage::encodeFrameH264(const Mat &frame, QVector<uchar> &encodedData) {
    qDebug() << "encodeFrameH264 started";
    Mat yuv;
    cvtColor(frame, yuv, COLOR_BGR2YUV_I420);
    if (yuv.empty()) {
        qDebug() << "yuv is empty!";
        return false;
    } else {
        qDebug() << "yuv is not empty, size:" << yuv.cols << "x" << yuv.rows;
    }

    static int frame_count = 0;
    avFrame->pts = frame_count++;  // 更新帧计数器并设置 PTS

    memcpy(avFrame->data[0], yuv.data, codecContext->width * codecContext->height);
    memcpy(avFrame->data[1], yuv.data + codecContext->width * codecContext->height, codecContext->width * codecContext->height / 4);
    memcpy(avFrame->data[2], yuv.data + codecContext->width * codecContext->height * 5 / 4, codecContext->width * codecContext->height / 4);

    if (avcodec_send_frame(codecContext, avFrame) < 0)
    {
        qDebug() << "avcodec_send_frame is failed";
        return false;
    }

    encodedData.clear();

    // 尝试获取编码后的数据包
        int ret = avcodec_receive_packet(codecContext, pkt);
        if (ret == 0) {
            qDebug() << "Received packet, size:" << pkt->size;
            int oldSize = encodedData.size();
            encodedData.resize(oldSize + pkt->size);
            memcpy(encodedData.data() + oldSize, pkt->data, pkt->size);
            av_packet_unref(pkt);  // 清除数据包
        } else {
            qDebug() << "avcodec_receive_packet failed with error code" << ret;
            return false;
        }

        qDebug() << "After avcodec_receive_packet";



    return !encodedData.empty();
}

void ProcessImage::sendUdpPackets(const QVector<uchar> &data) {

     quint16  sequenceNumber = 0;

    // 将 QVector<uchar> 转换为 QByteArray
    QByteArray packet(reinterpret_cast<const char*>(data.data()), data.size());

    const int maxRtpPayloadSize = 1400;  // 设定每个 RTP 包的最大负载大小，稍小于 1500 字节以考虑头部

    // 计算数据包数量
    int numPackets = (packet.size() + maxRtpPayloadSize - 1) / maxRtpPayloadSize;

    // 分割数据包并逐个发送 14000 10 1400 2800
    for (int packetIndex  = 0; packetIndex  < numPackets; ++packetIndex ) {
        int offset = packetIndex  * maxRtpPayloadSize;
        int size = qMin(maxRtpPayloadSize, packet.size() - offset);

        QByteArray packetFragment = packet.mid(offset, size);

        bool isLastPacket = (packetIndex == numPackets - 1);
        qDebug() << " packetIndex:" << packetIndex;
        qDebug() << " numPackets-1:" << numPackets-1;
        qDebug() << " isLastPacket:" << isLastPacket;

        // 创建 RTP 包头
        QByteArray rtpPacket;
        rtpPacket.resize(12 + packetFragment.size());
        RTPHeader *rtpHeader = reinterpret_cast<RTPHeader *>(rtpPacket.data());

        // 设置 RTP 包头
        rtpHeader->version_p_x_cc = (2 << 6); // 设置版本号等字段
        rtpHeader->m_pt = 96;
        rtpHeader->sequenceNumber = qToBigEndian(sequenceNumber); // 序列号
        //rtpHeader->sequenceNumber = sequenceNumber++;
        qDebug() << "sequenceNumber after:" << sequenceNumber;
        qDebug() << "rtpHeader->sequenceNumber after:" << rtpHeader->sequenceNumber;
        qDebug() << "rtpHeader->sequenceNumber after:" << qFromBigEndian(rtpHeader->sequenceNumber);
        rtpHeader->timestamp = qToBigEndian(QDateTime::currentMSecsSinceEpoch() & 0xFFFFFFFF); // 时间戳
        rtpHeader->ssrc = qToBigEndian(0x12345678); // SSRC
        sequenceNumber++;

        // 设置 Marker 位（最后一个包）
        if (isLastPacket) {
            rtpHeader->m_marker = 1;  // 设置 Marker 位为 1，表示这是最后一个包
        } else {
            rtpHeader->m_marker = 0;  // 清除 Marker 位
        }
        qDebug() << "sequenceNumber:" << sequenceNumber;
        qDebug() << "rtpHeader->sequenceNumber:" << rtpHeader->sequenceNumber;
        qDebug() << "rtpHeader->m_marker:" << rtpHeader->m_marker;

       // 将数据复制到 RTP 包
          memcpy(rtpPacket.data() + 12, packetFragment.data(), packetFragment.size());

        // 构造 RTP 包并发送
        emit dataReadyToUpload(rtpPacket);
    }
}


